//L298 Motor Controller Pin Assignment
// Motor A pin connections (Front Left)
int enAF = 10;
int in1F = 2;
int in2F = 3;

// Motor B pin connections (Front Right)
int enBF = 11;
int in3F = 4;
int in4F = 5;

// Motor C pin connections (Back Left)
int enAB = 12;
int in1B = 6;
int in2B = 7;

// Motor D pin connections (Back Right)
int enBB = 13;
int in3B = 8;
int in4B = 9;

//––––––––––––––––––––––––––––––––––––––––

void setup() {
  pinMode(enAF, OUTPUT);  pinMode(enBF, OUTPUT); //set front motor pins as outputs
  pinMode(in1F, OUTPUT);  pinMode(in2F, OUTPUT);
  pinMode(in3F, OUTPUT);  pinMode(in4F, OUTPUT);

  pinMode(enAB, OUTPUT);  pinMode(enBB, OUTPUT); //set back motor pins as outputs
  pinMode(in1B, OUTPUT);  pinMode(in2B, OUTPUT);
  pinMode(in3B, OUTPUT);  pinMode(in4B, OUTPUT);

  stopMotors(); //initialize robot to STOP
}

void loop() { //test the functions
  driveForward(153);   delay(2000);   // 60% speed forward  for 2s
  stopMotors();        delay(500);

  turnRight(89);       delay(1000);   // 35% speed right    for 1s
  stopMotors();        delay(500);

  turnLeft(89);        delay(1000);   // 35% speed left     for 1s
  stopMotors();        delay(500);
  
  driveBackward(153);  delay(2000);   // 60% speed backward for 2s
  stopMotors();        delay(4000);  //stop for 4 seconds
}

// ─────────────────────────────────────────────
// DRIVING FUNCTIONS
// Speed: PWM value 0–255
// ─────────────────────────────────────────────

void driveForward(int speed) {
  // Right side drives forward, left side drives forwards
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - forward
  digitalWrite(in1F, LOW);
  digitalWrite(in2F, HIGH);

  // Front Right - forward
  digitalWrite(in3F, LOW);
  digitalWrite(in4F, HIGH);

  // Back Left - forward
  digitalWrite(in1B, LOW);
  digitalWrite(in2B, HIGH);

  // Back Right - forward
  digitalWrite(in3B, LOW);
  digitalWrite(in4B, HIGH);
}

void driveBackward(int speed) {
  // Left side drives backwards, right side drives backward
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - backwards
  digitalWrite(in1F, HIGH);
  digitalWrite(in2F, LOW);

  // Front Right - backward
  digitalWrite(in3F, HIGH);
  digitalWrite(in4F, LOW);

  // Back Left - backwards
  digitalWrite(in1B, HIGH);
  digitalWrite(in2B, LOW);

  // Back Right - backward
  digitalWrite(in3B, HIGH);
  digitalWrite(in4B, LOW);
}


void turnRight(int speed) {
  // Left side drives forward, right side drives backward
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - forward
  digitalWrite(in1F, HIGH);
  digitalWrite(in2F, LOW);

  // Front Right - backward
  digitalWrite(in3F, LOW);
  digitalWrite(in4F, HIGH);

  // Back Left - forward
  digitalWrite(in1B, LOW);
  digitalWrite(in2B, HIGH);

  // Back Right - backward
  digitalWrite(in3B, HIGH);
  digitalWrite(in4B, LOW);
}

void turnLeft(int speed) {
   // Left side drives backward, right side drives forward)
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - forward
  digitalWrite(in1F, LOW);
  digitalWrite(in2F, HIGH);

  // Front Right - backward
  digitalWrite(in3F, HIGH);
  digitalWrite(in4F, LOW);

  // Back Left - forward
  digitalWrite(in1B, HIGH);
  digitalWrite(in2B, LOW);

  // Back Right - backward 
  digitalWrite(in3B, LOW);
  digitalWrite(in4B, HIGH);
}

void stopMotors() {
  digitalWrite(in1F, LOW);
  digitalWrite(in2F, LOW);
  digitalWrite(in3F, LOW);
  digitalWrite(in4F, LOW);

  digitalWrite(in1B, LOW);
  digitalWrite(in2B, LOW);
  digitalWrite(in3B, LOW);
  digitalWrite(in4B, LOW);
}
