//L298 Motor Controller Pin Assignment
// Motor A pin connections (Front Left)
int enAF = 9;
int in1F = 8;
int in2F = 7;

// Motor B pin connections (Front Right)
int enBF = 3;
int in3F = 4;
int in4F = 5;

// Motor C pin connections (Back Left)
int enAB = 29;
int in1B = 28;
int in2B = 27;

// Motor D pin connections (Back Right)
int enBB = 36;
int in3B = 37;
int in4B = 38;

//––––––––––––––––––––––––––––––––––––––––

void setup() {
  pinMode(enAF, OUTPUT);  pinMode(enBF, OUTPUT); //set front motor pins as outputs
  pinMode(in1F, OUTPUT);  pinMode(in2F, OUTPUT);
  pinMode(in3F, OUTPUT);  pinMode(in4F, OUTPUT);

  pinMode(enAB, OUTPUT);  pinMode(enBB, OUTPUT); //set back motor pins as outputs
  pinMode(in1B, OUTPUT);  pinMode(in2B, OUTPUT);
  pinMode(in3B, OUTPUT);  pinMode(in4B, OUTPUT);

  stopMotors(); //initialize robot to STOP
}

void loop() { //test the functions
  driveForward(153);   delay(2000);   // 60% speed forward  for 2s
  stopMotors();        delay(500);

  turnRight(89);       delay(1000);   // 35% speed right    for 1s
  stopMotors();        delay(500);

  turnLeft(89);        delay(1000);   // 35% speed left     for 1s
  stopMotors();        delay(500);

  driveBackward(153);  delay(2000);   // 60% speed backward for 2s
  stopMotors();        delay(500);
}

// ─────────────────────────────────────────────
// DRIVING FUNCTIONS
// Speed: PWM value 0–255
// ─────────────────────────────────────────────

void driveForward(int speed) {
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - forward (CW)
  digitalWrite(in1F, HIGH);
  digitalWrite(in2F, LOW);

  // Front Right - forward (CW)
  digitalWrite(in3F, LOW);
  digitalWrite(in4F, HIGH);

  // Back Left - forward (CW)
  digitalWrite(in1B, HIGH);
  digitalWrite(in2B, LOW);

  // Back Right - forward (CW)
  digitalWrite(in3B, LOW);
  digitalWrite(in4B, HIGH);
}

void driveBackward(int speed) {
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - backward (CCW)
  digitalWrite(in1F, LOW);
  digitalWrite(in2F, HIGH);

  // Front Right - backward (CCW)
  digitalWrite(in3F, HIGH);
  digitalWrite(in4F, LOW);

  // Back Left - backward (CCW)
  digitalWrite(in1B, LOW);
  digitalWrite(in2B, HIGH);

  // Back Right - backward (CCW)
  digitalWrite(in3B, HIGH);
  digitalWrite(in4B, LOW);
}

void turnRight(int speed) {
  // Left side drives forward, right side drives backward → spins CW (right)
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - forward (CW)
  digitalWrite(in1F, HIGH);
  digitalWrite(in2F, LOW);

  // Front Right - backward (CCW)
  digitalWrite(in3F, HIGH);
  digitalWrite(in4F, LOW);

  // Back Left - forward (CW)
  digitalWrite(in1B, HIGH);
  digitalWrite(in2B, LOW);

  // Back Right - backward (CCW)
  digitalWrite(in3B, HIGH);
  digitalWrite(in4B, LOW);
}

void turnLeft(int speed) {
  // Right side drives forward, left side drives backward → spins CCW (left)
  analogWrite(enAF, speed);
  analogWrite(enBF, speed);
  analogWrite(enAB, speed);
  analogWrite(enBB, speed);

  // Front Left - backward (CCW)
  digitalWrite(in1F, LOW);
  digitalWrite(in2F, HIGH);

  // Front Right - forward (CW)
  digitalWrite(in3F, LOW);
  digitalWrite(in4F, HIGH);

  // Back Left - backward (CCW)
  digitalWrite(in1B, LOW);
  digitalWrite(in2B, HIGH);

  // Back Right - forward (CW)
  digitalWrite(in3B, LOW);
  digitalWrite(in4B, HIGH);
}

void stopMotors() {
  digitalWrite(in1F, LOW);
  digitalWrite(in2F, LOW);
  digitalWrite(in3F, LOW);
  digitalWrite(in4F, LOW);

  digitalWrite(in1B, LOW);
  digitalWrite(in2B, LOW);
  digitalWrite(in3B, LOW);
  digitalWrite(in4B, LOW);
}
